/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "placeholder.svg",
    "revision": "35707bd9960ba5281c72af927b79291f"
  }, {
    "url": "index.html",
    "revision": "c5d411a088992c8d089431c1f9bbd150"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "assets/xlsx-D_0l8YDs.js",
    "revision": null
  }, {
    "url": "assets/workHoursTracker-4AqC5dbC.js",
    "revision": null
  }, {
    "url": "assets/wallet-D9i22dUS.js",
    "revision": null
  }, {
    "url": "assets/users-mewVPpwG.js",
    "revision": null
  }, {
    "url": "assets/user-round-D6YjFs6u.js",
    "revision": null
  }, {
    "url": "assets/user-check-CRdqC-s5.js",
    "revision": null
  }, {
    "url": "assets/ui-BUT-zShd.js",
    "revision": null
  }, {
    "url": "assets/triangle-alert-DyAJpubN.js",
    "revision": null
  }, {
    "url": "assets/sliders-horizontal-Cdo8okoy.js",
    "revision": null
  }, {
    "url": "assets/settings-_VSq_Jmq.js",
    "revision": null
  }, {
    "url": "assets/send-LF5CE-jD.js",
    "revision": null
  }, {
    "url": "assets/save-CIAiTJAZ.js",
    "revision": null
  }, {
    "url": "assets/receipt-DUkRRQgA.js",
    "revision": null
  }, {
    "url": "assets/printer-Bd1Glm_R.js",
    "revision": null
  }, {
    "url": "assets/pencil-2w-k5i-H.js",
    "revision": null
  }, {
    "url": "assets/pen-Dyv7Z6xg.js",
    "revision": null
  }, {
    "url": "assets/partsStore-CBSayJ_N.js",
    "revision": null
  }, {
    "url": "assets/package-QwRAxjZm.js",
    "revision": null
  }, {
    "url": "assets/layers-6xQN0GEp.js",
    "revision": null
  }, {
    "url": "assets/info-C_BmNm7b.js",
    "revision": null
  }, {
    "url": "assets/index-B3_I7ur3.css",
    "revision": null
  }, {
    "url": "assets/index-B0iJozPQ.js",
    "revision": null
  }, {
    "url": "assets/fullBackup-Ds4jUIhY.js",
    "revision": null
  }, {
    "url": "assets/filter-BerMKO3l.js",
    "revision": null
  }, {
    "url": "assets/file-text-D2oPkQjt.js",
    "revision": null
  }, {
    "url": "assets/file-spreadsheet-DYiO6Alv.js",
    "revision": null
  }, {
    "url": "assets/external-link-Cbf1Fh4q.js",
    "revision": null
  }, {
    "url": "assets/exportUtils-DgKVq2fF.js",
    "revision": null
  }, {
    "url": "assets/ellipsis-vertical-ixgnVDue.js",
    "revision": null
  }, {
    "url": "assets/dateConverter-CfnmqpML.js",
    "revision": null
  }, {
    "url": "assets/credit-card-C8uFRDLg.js",
    "revision": null
  }, {
    "url": "assets/clipboard-list-CcTDkxvv.js",
    "revision": null
  }, {
    "url": "assets/circle-help-BSMyfyxy.js",
    "revision": null
  }, {
    "url": "assets/chevron-right-B1EckPr4.js",
    "revision": null
  }, {
    "url": "assets/calendar-days-D5Os9Nvn.js",
    "revision": null
  }, {
    "url": "assets/ban-D1BALdBz.js",
    "revision": null
  }, {
    "url": "assets/arrow-right-zvRpwvkT.js",
    "revision": null
  }, {
    "url": "assets/ZonesPage-BtxmUdNK.js",
    "revision": null
  }, {
    "url": "assets/TechnicianMobileApp-CLQJz6LN.js",
    "revision": null
  }, {
    "url": "assets/TechnicianDashboard-DYWAqFRa.js",
    "revision": null
  }, {
    "url": "assets/StaffPage-C_JDD1GF.js",
    "revision": null
  }, {
    "url": "assets/ServicesCalendar-Bmic2j69.js",
    "revision": null
  }, {
    "url": "assets/ServiceForm-Btb6ZQog.js",
    "revision": null
  }, {
    "url": "assets/ScheduleManagementPage-Sb_2v97N.js",
    "revision": null
  }, {
    "url": "assets/PartsPage-BSNr6cuZ.js",
    "revision": null
  }, {
    "url": "assets/NumberStepper-Dox5vp4y.js",
    "revision": null
  }, {
    "url": "assets/NewContractWizard-B_k1MN7Z.js",
    "revision": null
  }, {
    "url": "assets/MarketingFlyout-BC3XWySv.js",
    "revision": null
  }, {
    "url": "assets/CustomersPage-dw3KT2Rt.js",
    "revision": null
  }, {
    "url": "assets/CustomerReportsPage-CiX8u8Pw.js",
    "revision": null
  }, {
    "url": "assets/CustomerPortalView-C_rmqs1z.js",
    "revision": null
  }, {
    "url": "assets/CsvUploadPage-4mP0bczA.js",
    "revision": null
  }, {
    "url": "assets/CpanelSettingsPage-D4tUiiD4.js",
    "revision": null
  }, {
    "url": "assets/ContractsPage-BA6CL21p.js",
    "revision": null
  }, {
    "url": "assets/ContractView-DIk8MHzV.js",
    "revision": null
  }, {
    "url": "assets/ChecklistSettingsPage-cS5W-7jU.js",
    "revision": null
  }, {
    "url": "assets/AccessManagementPage-Qi4y9Reu.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1f1216864a5c781887515c844f834ec2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
